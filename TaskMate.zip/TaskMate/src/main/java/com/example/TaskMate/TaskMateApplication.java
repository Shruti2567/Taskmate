package com.example.TaskMate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskMateApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskMateApplication.class, args);
	}

}
